from __future__ import annotations
from typing import Optional, List
from datetime import datetime
from sqlmodel import SQLModel

class TagBase(SQLModel):
    name: str
    description: Optional[str] = None

class TagCreate(TagBase):
    pass

class TagUpdate(SQLModel):
    name: Optional[str] = None
    description: Optional[str] = None

class TagResponse(SQLModel):
    id: int
    name: str
    description: Optional[str] = None
    
    # Audit fields (read-only)
    created_at: datetime
    last_updated_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None
    created_by: Optional[str] = None
    last_updated_by: Optional[str] = None
    
    # Related contracts (optional, populated when needed)
    contracts: Optional[List["ContractResponse"]] = None

class TagRead(SQLModel):
    id: int
    name: str
    description: Optional[str] = None
    
    class Config:
        from_attributes = True

# Forward reference resolution  
from backend.contracts.schemas.contract import ContractResponse
TagResponse.model_rebuild()