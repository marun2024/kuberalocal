from __future__ import annotations
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import UniqueConstraint
from sqlalchemy.types import Text

from backend.core.core_common_base import CoreCommonBase

if TYPE_CHECKING:
    from backend.contracts.models.contract import Contract
    from backend.contracts.models.tag_contract_link import TagContractLink

class Tag(CoreCommonBase, table=True):
    __tablename__ = "tag"
    __table_args__ = (
        UniqueConstraint("name", name="uq_tag_name"),
    )

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=255, index=True)
    description: Optional[str] = Field(default=None, sa_type=Text)

    # Many-to-many relationship with contracts
    contracts: List["Contract"] = Relationship(
        back_populates="tags",
        link_model="TagContractLink"
    )