from __future__ import annotations
from typing import Optional
from sqlmodel import SQLModel, Field
from sqlalchemy import UniqueConstraint, ForeignKey

from backend.core.core_common_base import CoreCommonBase

class TagContractLink(CoreCommonBase, table=True):
    __tablename__ = "tag_contract_link"
    __table_args__ = (
        UniqueConstraint("tag_id", "contract_id", name="uq_tag_contract"),
    )

    id: Optional[int] = Field(default=None, primary_key=True)
    
    tag_id: int = Field(
        sa_column_kwargs={
            "name": "tag_id",
            "nullable": False
        },
        foreign_key="tag.id"
    )
    
    contract_id: int = Field(
        sa_column_kwargs={
            "name": "contract_id", 
            "nullable": False
        },
        foreign_key="contract.id"
    )