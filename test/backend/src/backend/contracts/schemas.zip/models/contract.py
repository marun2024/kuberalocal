from __future__ import annotations

from typing import Optional, List, TYPE_CHECKING
from datetime import date, timedelta
from decimal import Decimal
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import UniqueConstraint
from sqlalchemy.types import String, Text, Date, Boolean, Numeric, Integer, Interval

from backend.core.core_common_base import CoreCommonBase

if TYPE_CHECKING:
    from backend.contracts.models.tag import Tag
    from backend.contracts.models.tag_contract_link import TagContractLink

class Contract(CoreCommonBase, table=True):
    __tablename__ = "contract"
    __table_args__ = (
        UniqueConstraint("reference_number", name="uq_contract_reference_number"),
    )

    id: Optional[int] = Field(default=None, primary_key=True)

    # Core fields
    title: str = Field(max_length=255)
    service_provider_id: int = Field()
    reference_number: Optional[str] = Field(default=None, max_length=100)
    description: Optional[str] = Field(default=None, sa_type=Text)

    # Dates and intervals
    start_date: date = Field(sa_type=Date)
    end_date: Optional[date] = Field(default=None, sa_type=Date)
    auto_renewal_date: Optional[date] = Field(default=None, sa_type=Date)
    renewal_notice_deadline: Optional[timedelta] = Field(default=None, sa_type=Interval)
    signature_date: Optional[date] = Field(default=None, sa_type=Date)

    # Money / misc
    total_value: Optional[Decimal] = Field(default=None, sa_type=Numeric(18, 2))
    cost: Optional[Decimal] = Field(default=None, sa_type=Numeric(18, 2))
    payment_schedule_type_id: Optional[int] = Field(default=None)
    internal_owner: Optional[str] = Field(default=None, max_length=255)
    license_count: Optional[int] = Field(default=None)
    termination_clauses: Optional[str] = Field(default=None, sa_type=Text)
    indemnification_terms: Optional[str] = Field(default=None, sa_type=Text)
    renewal_alert_flag: bool = Field(default=False, sa_type=Boolean)
    notes: Optional[str] = Field(default=None, sa_type=Text)

    # Many-to-many relationship with tags
    tags: List["Tag"] = Relationship(
        back_populates="contracts",
        link_model="TagContractLink"
    )